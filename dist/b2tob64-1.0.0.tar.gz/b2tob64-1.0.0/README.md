This package allows for custom encoding between base2 (bianary) and base 64.
WARNING: THIS WILL NOT TRANSLATE other b64 encodings and will NOT be able to encode/decode the same values
